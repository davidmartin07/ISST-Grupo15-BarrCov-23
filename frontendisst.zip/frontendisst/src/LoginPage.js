import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {Link} from "react-router-dom";
import axios from 'axios';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [voluntario, setVoluntario] = useState(false); //Para ver si quieren entrar como visitantes o no

  const navigate = useNavigate();// Importamos useNavigate

  const handleLogin = (event) => {
    event.preventDefault();

/*    axios.post('URL_DE_LA_API', { // realizar la petición HTTP POST
      email: email,
      password: password
    })
    .then(response => {
      console.log(response); // si la petición es exitosa, mostrar la respuesta en la consola
*/
      // realizar la lógica para redirigir al usuario según el tipo de usuario y la respuesta de la API
      if ((email === 'example@example.com' || email === 'admin@admin.com') && password === '12345') { //Este if es demasiado largo pero es para que se entienda lo que se hace
        //En el backend tienen que decir si eres comprador o vendedor (por ejemplo isComprador: true)
        //if(isVendedor===true){                                                                // Los vendedores
          //navigate("/VendedorPage");                                                          // Redirigimos automáticamente
        //} else if (isVendedor===false && isVoluntario===false){                                // Los compradores que sean NO voluntarios
          //navigate("/seleccionarTienda");       
        // } else if (isVendedor===false && isVoluntario===true && voluntario) {               //Los compradores que sean voluntarios y QUIERAN ACCEDER AL MENÚ DE VOLUNTARIO
          //navigate("/VoluntarioPage"); 
        // } else {                                                                             //Compradores, voluntarios y QUE QUIERAN COMPRAR
          navigate("/seleccionarTienda"); 
        //}
        //}
        //}
      } else {
        setError("El email o la contraseña son incorrectos");
      }
/*    })
    .catch(error => {
      console.log(error);
      setError("Error al iniciar sesión.");
    });*/
  };  

  const accesoVoluntario = (event) => {
    setVoluntario(event.target.checked);
  };


  return (
    <div>
      <h1>Iniciar sesión</h1>
      <form onSubmit={handleLogin}>
        <label>
          Correo electrónico:
          <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
        </label>
        <br />
        <label>
          Contraseña:
          <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required />
        </label>
        <br />
        <Link to={"/RegistroPage"}>
          <button id="registro" variant="primary">Crea una cuenta</button>
        </Link> 
        <button type="submit">Aceptar</button> 
        {error && <p>{error}</p>} {/* Mostramos el mensaje de error si existe */}  

        <div>
          <label>
            <input type="checkbox" checked={voluntario} onChange={accesoVoluntario} />
            Soy voluntario
          </label>
        </div>

      </form>
    </div>
  );
}

export default LoginPage;