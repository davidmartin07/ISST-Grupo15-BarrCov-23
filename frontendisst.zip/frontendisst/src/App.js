import { useState, useEffect } from "react";
import './App.css';
import LoginPage from './LoginPage';
import VoluntarioMenu from "./VoluntarioMenu";
import VendedorMenu from "./VendedorMenu";
import CompradorTiendas from './CompradorTiendas';
import RegistroPage from './RegistroPage';
import Pagar from "./Pagar";
import ProductList from "./ProductList";
import Spinner from 'react-bootstrap/Spinner';
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  useEffect(() => {
    async function fetchData() {
      setTimeout(() => {
        setLoading(false);
      }, 500);
    }

    fetchData();
  }, []);

  const [loading, setLoading] = useState(true);
  return (
    <div className="App">
      {loading ? (
        <Spinner id="loading" className="spinner" animation="border" size="sm" />
      ) : (
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/VendedorMenu" element={<VendedorMenu />} />
            <Route path="/VoluntarioMenu" element={<VoluntarioMenu />} />
            <Route path="/RegistroPage" element={<RegistroPage />} />
            <Route path="/Pagar" element={<Pagar />} />
            <Route path="/ProductList" element={<ProductList />} />
            <Route path="/seleccionarTienda" element={<CompradorTiendas />} />
          </Routes>
        </BrowserRouter>
      )}
    </div>
  );
}

export default App;

